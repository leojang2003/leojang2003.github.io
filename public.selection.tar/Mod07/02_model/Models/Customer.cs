﻿namespace StarterM.Models
{
    public class Customer
    {
        public required string CustomerID { get; set; }
        public required string CompanyName { get; set; }
        public required string Country { get; set; }

    }
}
