using NLog.Web;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Host.UseNLog(new NLogAspNetCoreOptions() { RemoveLoggerFactoryFilter = false });
//builder.Logging.AddFilter((category, level) =>
//    category == "MyLog" );
//builder.Logging.AddFilter((category, level) =>
//    category == "MyLog" && level>=LogLevel.Warning);
//=========================================
var app = builder.Build();
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();
NLog.LogManager.Shutdown();