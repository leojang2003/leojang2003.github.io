﻿using Microsoft.AspNetCore.Mvc;
using StarterM.Services;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        readonly IMyService _myService;

        public HomeController(IMyService myService)
        {
            _myService = myService;
        }

        public IActionResult Index()
        {
            ViewData["Id"] = _myService.Id;
            return View();
        }
    }
}
