﻿namespace StarterM.Services
{
    public interface IMyService
    {
        Guid Id { get; }
    }
    public class MyService : IMyService, IDisposable
    {
       // public Guid Id => Guid.NewGuid();
       public Guid Id { get; } = Guid.NewGuid();

        public void Dispose()
        {
            Console.WriteLine(nameof(Dispose));
        }
    }
}
