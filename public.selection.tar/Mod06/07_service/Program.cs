using StarterM.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
//builder.Services.AddTransient<IMyService, MyService>();
//builder.Services.AddScoped<IMyService, MyService>();
//builder.Services.AddSingleton<IMyService, MyService>();

using MyService myService = new MyService();
builder.Services.AddSingleton<IMyService>(myService);

//IMyService myService = new MyService();
//builder.Services.AddSingleton(myService);
//Console.WriteLine(("Program",myService.Id));
//=========================================
var app = builder.Build();
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();
