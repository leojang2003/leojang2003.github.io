﻿namespace StarterM.Models
{
    public class MyLogEvents
    {
        public const int FormatError = 1000;
        public const int ArgumentNullError = 1001;
        public const int OverflowError = 1002;

    }
}
