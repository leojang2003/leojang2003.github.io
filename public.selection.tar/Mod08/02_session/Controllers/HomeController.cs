﻿using Microsoft.AspNetCore.Mvc;
using StarterM.Models;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetCount()
        {
            int i = 1;
            var counter = HttpContext.Session.GetInt32("counter");

            if (counter.HasValue)
            {
                i = counter.Value + 1;
            }
            HttpContext.Session.SetInt32("counter", i);

            return Content($"Count:{i}");
        }
        public IActionResult SetSession()
        {
            HttpContext.Session.Set<Employee>("employee", new()
            {
                Id = 1,
                Name = "Mary",
                Age = 33
            });
            return Content("Set Session");
        }
        public IActionResult GetSession()
        {
            Employee? employee = HttpContext.Session.Get<Employee>("employee");

            return Content($"Employee Name:{employee?.Name}, Age: {employee?.Age}");
        }
        public IActionResult GetSession2()
        {
            string? result = HttpContext.Session.GetString("employee");

            return Content($"Result:{result}");
        }
    }
}
