﻿using Microsoft.AspNetCore.Mvc;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult WriteCookie()
        {
            //Response.Cookies.Append("userName", "Mary");

            Response.Cookies.Append("userName", "Mary", new CookieOptions {Expires=DateTime.Now.AddDays(1) });
            return Content("Write Cookie...");
        }

        public IActionResult ReadCookie()
        {
            string? value = Request.Cookies["userName"];
            return Content($"User Name: {value}");
        }

    }
}
