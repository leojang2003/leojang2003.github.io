﻿using Microsoft.AspNetCore.Mvc;

namespace StarterM.Controllers
{
    public class StatusCodeController : Controller
    {
        public IActionResult Index(string code)
        {
            ViewData["code"] = code;
            return View();
        }
    }
}
