using static System.Net.Mime.MediaTypeNames;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
//=========================================
var app = builder.Build();
app.Environment.EnvironmentName = Environments.Production;
if (app.Environment.IsDevelopment())
{
    app.UseStatusCodePages();
}
else
{
    app.UseExceptionHandler("/Error");
    // app.UseStatusCodePages(Text.Html,"<h1>Status Code: {0}</h1>");
    //app.UseStatusCodePagesWithRedirects("/StatusCode?code={0}");
    app.UseStatusCodePagesWithReExecute("/StatusCode", "?code={0}");
}
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();
