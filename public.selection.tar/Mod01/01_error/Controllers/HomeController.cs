﻿using Microsoft.AspNetCore.Mvc;

namespace StarterM.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string number)
        {
            int i = int.Parse(number);
            ViewData["result"] = i*i;
            return View();
        }
    }
}
