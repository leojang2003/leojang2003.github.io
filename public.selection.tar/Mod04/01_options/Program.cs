using StarterM.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.Configure<WebsiteProfile>(options => { 
    options.Email = "config@uuu.com.tw";
    options.ThemeColor = "lightblue";
});
//=========================================
var app = builder.Build();
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();
