﻿namespace StarterM.Models
{
    public class WebsiteProfile
    {
        public string Email { get; set; } = "default@uuu.com.tw";
        public string ThemeColor { get; set; } = "yellow";
    }
}
