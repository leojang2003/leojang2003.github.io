using StarterM.Models;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
//builder.Configuration.AddJsonFile("profile.json",true,true); 
//builder.Configuration.AddInMemoryCollection(new Dictionary<string,string?>(){
//    ["email"]="memory@uuu.com,tw",
//    ["themecolor"]="orange"
//});
builder.Services.Configure<WebsiteProfile>(builder.Configuration);
Console.WriteLine("=============================");
foreach (var item in (builder.Configuration as IConfigurationRoot).Providers)
{
    Console.WriteLine(item);
}
Console.WriteLine("=============================");
//=========================================
var app = builder.Build();
app.UseStaticFiles();
app.MapDefaultControllerRoute();
app.Run();
