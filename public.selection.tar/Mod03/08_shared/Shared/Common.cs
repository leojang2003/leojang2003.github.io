﻿namespace StarterM.Shared
{
    public class Common
    {
    }
}
